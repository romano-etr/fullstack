let canvas = document.getElementById('canvas');
let ctx = canvas.getContext('2d');

ctx.beginPath ();
ctx.fillStyle = '#808080';
ctx.fillRect (0,300,400,400);
ctx.closePath ();

ctx.beginPath ();
ctx.fillStyle = '#86471a';
ctx.fillRect (150,200,100,100);
ctx.closePath ();

ctx.beginPath ();
ctx.fillStyle = '#f5694d';
ctx.moveTo (200,150);
ctx.lineTo (250,200);
ctx.lineTo (150,200);
ctx.fill ();
ctx.closePath ();

ctx.beginPath ();
ctx.fillStyle = '#fcff2d';
ctx.arc (300,100,50,0*Math.PI,2*Math.PI);
ctx.fill ();
ctx.closePath ();

ctx.beginPath ();
ctx.fillStyle = '#458efc';
ctx.arc (0,300,50,1.5*Math.PI,2.5*Math.PI);
ctx.fill ();
ctx.closePath ();

ctx.beginPath ();
ctx.fillStyle = '#458efc';
ctx.arc (150,400,50,1*Math.PI,2*Math.PI);
ctx.fill ();
ctx.closePath ();

ctx.beginPath ();
ctx.fillStyle = '#458efc';
ctx.moveTo (150,350);
ctx.lineTo (50,350);
ctx.lineTo (50,300);
ctx.lineTo (0,300);
ctx.lineTo (0,400);
ctx.lineTo (150,400);
ctx.fill ();
ctx.closePath ();

ctx.beginPath ();
ctx.fillStyle = '#47bdfd';
ctx.fillRect (160,210,30,30);
ctx.closePath ();

ctx.beginPath ();
ctx.fillStyle = '#47bdfd';
ctx.fillRect (210,210,30,30);
ctx.closePath ();

ctx.beginPath ();
ctx.fillStyle = '#624423';
ctx.fillRect (190,240,20,60);
ctx.closePath ();

ctx.beginPath ();
ctx.fillStyle = '#86471a';
ctx.fillRect (50,240,20,60);
ctx.closePath ();

ctx.beginPath ();
ctx.fillStyle = '#318a26';
ctx.arc (60,235,30,0*Math.PI,2*Math.PI);
ctx.fill ();
ctx.closePath ();

ctx.beginPath ();
ctx.fillStyle = '#86471a';
ctx.fillRect (340,290,20,60);
ctx.closePath ();

ctx.beginPath ();
ctx.fillStyle = '#318a26';
ctx.arc (350,285,30,0*Math.PI,2*Math.PI);
ctx.fill ();
ctx.closePath ();


let canvas2 = document.getElementById('canvas2');
let ctx2 = canvas2.getContext('2d');

ctx2.beginPath ();
ctx2.fillStyle = 'blue';
ctx2.fillRect (0,0,50,50);
ctx2.closePath ();

ctx2.beginPath ();
ctx2.fillStyle = 'red';
ctx2.fillRect (300,0,-50,50);
ctx2.closePath ();

ctx2.beginPath ();
ctx2.fillStyle = 'black';
ctx2.moveTo (300,300);
ctx2.lineTo (240,300);
ctx2.lineTo (240,270);
ctx2.lineTo (270,270);
ctx2.lineTo (270,240);
ctx2.lineTo (300,240);
ctx2.fill ();
ctx2.closePath

ctx2.beginPath ();
ctx2.fillStyle = 'yellow';
ctx2.moveTo (0,240);
ctx2.lineTo (30,240);
ctx2.lineTo (30,270);
ctx2.lineTo (60,270);
ctx2.lineTo (60,300);
ctx2.lineTo (0,300);
ctx2.fill ();
ctx2.closePath ();

ctx2.beginPath ();
ctx2.fillStyle = 'aqua';
ctx2.fillRect (0,120,30,60)
ctx2.closePath ();

ctx2.beginPath ();
ctx2.fillStyle = 'aqua';
ctx2.fillRect (270,135,30,30);
ctx2.closePath ();

ctx2.beginPath ();
ctx2.fillStyle = 'red';
ctx2.fillRect (110,150,40,40);
ctx2.closePath ();

ctx2.beginPath ();
ctx2.fillStyle = 'black';
ctx2.fillRect (150,150,1,110);
ctx2.closePath ();

ctx2.beginPath ();
ctx2.lineWidth = 1;
ctx2.fillStyle = 'aqua';
ctx2.strokeStyle = 'green';
ctx2.arc (150,300,40,1*Math.PI,2*Math.PI);
ctx2.fill ();
ctx2.stroke ();
ctx2.closePath ();

ctx2.beginPath ();
ctx2.lineWidth = 1;
ctx2.strokeStyle = 'green';
ctx2.arc (150,300,60,1.5*Math.PI,2*Math.PI);
ctx2.stroke ();
ctx2.closePath ();

ctx2.beginPath ();
ctx2.lineWidth = 1;
ctx2.strokeStyle = 'green';
ctx2.arc (150,300,80,1*Math.PI,1.5*Math.PI);
ctx2.stroke ();
ctx2.closePath ();

ctx2.beginPath ();
ctx2.fillStyle = 'green';
ctx2.fillRect (0,150,300,1);
ctx2.closePath ();

ctx2.beginPath ();
ctx2.lineWidth = 1;
ctx2.fillStyle = 'yellow';
ctx2.strokeStyle = 'green';
ctx2.arc (70,220,15,0*Math.PI,2*Math.PI);
ctx2.fill ();
ctx2.stroke ();
ctx2.closePath ();

ctx2.beginPath ();
ctx2.lineWidth = 1;
ctx2.fillStyle = 'yellow';
ctx2.strokeStyle = 'green';
ctx2.arc (230,220,15,0*Math.PI,2*Math.PI);
ctx2.fill ();
ctx2.stroke ();
ctx2.closePath ();

ctx2.beginPath ();
ctx2.strokeStyle = 'blue';
ctx2.moveTo (50,50);
ctx2.lineTo (150,150);
ctx2.stroke ();
ctx2.closePath ();

ctx2.beginPath ();
ctx2.strokeStyle = 'red';
ctx2.moveTo (250,50);
ctx2.lineTo (150,150);
ctx2.stroke ();
ctx2.closePath ();

ctx2.beginPath ();
ctx2.lineWidth = 1;
ctx2.strokeStyle = 'green';
ctx2.arc (150,150,60,1*Math.PI,2*Math.PI);
ctx2.stroke ();
ctx2.closePath ();

ctx2.beginPath ();
ctx2.lineWidth = 1;
ctx2.strokeStyle = 'green';
ctx2.arc (150,150,80,1*Math.PI,1.25*Math.PI);
ctx2.stroke ();
ctx2.closePath ();

ctx2.beginPath ();
ctx2.lineWidth = 1;
ctx2.strokeStyle = 'green';
ctx2.arc (150,150,80,1.75*Math.PI,2*Math.PI);
ctx2.stroke ();
ctx2.closePath ();

ctx2.beginPath ();
ctx2.lineWidth = 1;
ctx2.fillStyle = 'aqua';
ctx2.strokeStyle = 'blue';
ctx2.arc (150,115,15,0*Math.PI,2*Math.PI);
ctx2.fill ();
ctx2.stroke ();
ctx2.closePath ();

ctx2.beginPath ();
ctx2.lineWidth = 2;
ctx2.strokeStyle = 'black';
ctx2.strokeRect (0,0,300,300);
ctx2.closePath ();

ctx2.beginPath();
ctx2.fillStyle = 'black';
ctx2.font = "20px Arial"
ctx2.textAlign = "center";
ctx2.fillText("Canvas",150,50);
ctx2.closePath();
