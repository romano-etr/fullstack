def cadastrar_usuario():
    nome = input("Nome: ")
    email = input("Email: ")
    senha = input("Senha: ")

    with open("dados/usuarios.txt", "a") as arq:
        arq.write(f"{id};{nome};{email};{senha}\n")

def login():
    email = input("Email: ")
    senha = input("Senha: ")

    with open("dados/usuarios.txt", "r") as arq:
        for linha in arq:
            dados = linha.strip().split(";")

            if dados[2] == email and dados[3] == senha:
                return dados

def buscar_video():
    nome = input("Digite o nome: ")

    with open("dados/videos.txt", "r") as arq:
        for linha in arq:
            if nome.lower() in linha.lower():
                print(linha)