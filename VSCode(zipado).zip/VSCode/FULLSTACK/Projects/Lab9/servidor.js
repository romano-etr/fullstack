const path = require('path');
const express = require('express');
const { initDb, addPost, getAllPosts } = require('./db');

const app = express();
const port = process.env.PORT || 80;

initDb();

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: false }));

app.get('/', (req, res) => {
  res.render('index');
});

app.get('/projects', (req, res) => {
  res.redirect('/');
});

app.get('/blog', async (req, res) => {
  try {
    const posts = await getAllPosts();
    res.render('blog', { posts });
  } catch (error) {
    console.error('Erro ao buscar posts:', error);
    res.status(500).send('Erro interno ao buscar posts.');
  }
});

app.post('/posts', async (req, res) => {
  const { titulo, resumo, conteudo } = req.body;
  if (!titulo || !resumo || !conteudo) {
    return res.status(400).send('Todos os campos são obrigatórios.');
  }

  try {
    await addPost(titulo, resumo, conteudo);
    res.redirect('/blog');
  } catch (error) {
    console.error('Erro ao cadastrar post:', error);
    res.status(500).send('Erro interno ao cadastrar o post.');
  }
});

app.use((req, res) => {
  res.status(404).send('Página não encontrada.');
});

app.listen(port, () => {
  console.log(`Servidor rodando na porta ${port}`);
});
