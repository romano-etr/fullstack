const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.join(__dirname, 'blog.db');
let db;

function initDb() {
  db = new sqlite3.Database(dbPath, err => {
    if (err) {
      console.error('Erro ao abrir o banco:', err);
      process.exit(1);
    }

    db.run(
      `CREATE TABLE IF NOT EXISTS posts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        titulo TEXT NOT NULL,
        resumo TEXT NOT NULL,
        conteudo TEXT NOT NULL,
        criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
      )`
    );
  });
}

function addPost(titulo, resumo, conteudo) {
  return new Promise((resolve, reject) => {
    const sql = 'INSERT INTO posts (titulo, resumo, conteudo) VALUES (?, ?, ?)';
    db.run(sql, [titulo, resumo, conteudo], function (err) {
      if (err) {
        reject(err);
        return;
      }
      resolve(this.lastID);
    });
  });
}

function getAllPosts() {
  return new Promise((resolve, reject) => {
    const sql = 'SELECT id, titulo, resumo, conteudo, criado_em FROM posts ORDER BY criado_em DESC';
    db.all(sql, [], (err, rows) => {
      if (err) {
        reject(err);
        return;
      }
      resolve(rows);
    });
  });
}

module.exports = {
  initDb,
  addPost,
  getAllPosts
};
